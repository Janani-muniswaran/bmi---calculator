// String Es6+ 

let names = "JavaScript";
let frndName = "  React   "
// length 
console.log("Length : ",names.length);

// slice 
console.log("Slice : ",names.slice(0,4));

// UpperCase 
console.log("UpperCase : ",names.toUpperCase() );

// LowerCase  
console.log("LowerCase : ",names.toLowerCase());

// trim start/ end
console.log("Trim Start : ",frndName.trimStart());
console.log("Trim End : ", frndName.trimEnd());
console.log("Trim : ",frndName.trim());

// concat 

let FullName = names.concat(" ",frndName);
console.log("FullName : ",FullName);

// padStart 
console.log(names.padStart(15,' '));

// Repeat 
console.log("Repeat : ",names.repeat(5))

// Replace 
let place = "Tamilnadu";
console.log("Place : ",place.replace("Tamilnadu","Chennai"));
console.log(place);