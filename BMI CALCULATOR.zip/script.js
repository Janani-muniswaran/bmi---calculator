document.getElementById('calculate').addEventListener('click', function(e) {
    e.preventDefault();

    const weight = parseFloat(document.getElementById('weight').value);
    const height = parseFloat(document.getElementById('height').value);

    if (isNaN(weight) || isNaN(height)) {
        alert('Please enter valid numbers');
        return;
    }

    const bmi = weight / (height / 100) ** 2;
    const result = document.getElementById('result');

    if (bmi < 18.5) {
        result.textContent = `Your BMI is ${bmi.toFixed(2)} (Underweight)`;
    } else if (bmi < 25) {
        result.textContent = `Your BMI is ${bmi.toFixed(2)} (Normal)`;
    } else if (bmi < 30) {
        result.textContent = `Your BMI is ${bmi.toFixed(2)} (Overweight)`;
    } else {
        result.textContent = `Your BMI is ${bmi.toFixed(2)} (Obese)`;
    }
});
